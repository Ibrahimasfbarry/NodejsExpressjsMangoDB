module.exports = {
    'secretKey': '12345-67890-09876-54321',
    'mongoUrl' : 'mongodb://localhost:27017/nucampsite',
    'facebook': {
        clientId: '267850374701199',
        clientSecret: '19c6b9112d5f6732a3d9191d1b7faa1a'
    }
}